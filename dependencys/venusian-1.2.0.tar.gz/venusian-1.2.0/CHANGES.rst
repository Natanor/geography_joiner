1.2.0 (2019-01-08)
------------------

- Add support for Python 3.7.

- Drop support for Python 3.3.

1.1.0 (2017-04-24)
------------------

- Updated to using py.test instead of nosetest, and added support for Python
  3.4 -> 3.6

- Make scanning more resilient of metaclasses that return proxies for any
  attribute access.

- Fix bug where using the same venusian decorator on both a class and its
  methods would cause the method decorations to be ignored. See
  https://github.com/Pylons/venusian/issues/40

- Drop support for Python 2.6.

- Drop support for Python 3.2:  it is no longer supported by current
  packaging / CI tools.

- Support loaders that require the module name as argument to their
  ``get_filename()`` method. This fixes problems with zipped packages
  on Python 3.

- Micro-optimization when ignores are used (see
  https://github.com/Pylons/venusian/pull/20).

- A tox run now combines coverage between Py2 and Py3.

1.0 (2014-06-30)
----------------

- Fix an issue under PyPy > 2.0 where attached decorators may not be found.

- Drop support of Python 2.4 / 2.5 / Jython.

- Add ``lift`` and ``onlyliftedfrom`` class decorators to allow for inheritance
  of venusian decorators attached to superclass methods.  See the API
  documentation for more information.

- Fix bug where otherwise undecorated subclass of a superclass that had
  venusian decorators on it would inherit its superclass' decorations.
  Venusian decorators should have never been inherited implicitly.  See
  https://github.com/Pylons/venusian/issues/11#issuecomment-4977352

1.0a8 (2013-04-15)
------------------

- Pass ``ignore`` argument along recursively to ``walk_packages`` so custom
  ignore functions will ignore things recursively.  See
  https://github.com/Pylons/venusian/pull/16

- Don't run tox tests under Python 2.4 anymore (tox no longer supports 2.4).

1.0a7 (2012-08-25)
------------------

- Venusian now works on Python 3.3b2+ (importlib-based).

- Use nose-exclude instead of relying on fragile module-scope code to ensure
  we don't get errors resulting from import of fixture code during
  "nosetests".

- Bug fix: no longer suppress ``ImportError`` while scanning by default.  If
  you want to suppress ``ImportError`` while scanning, you'll now need use an
  ``onerror`` callback as described in the documentation.

1.0a6 (2012-04-23)
------------------

- Don't ignore decorated objects within their original locations if they
  happen to be imported into another module (remove ``seen`` set from invoke
  in venusian scanning).  See https://github.com/Pylons/venusian/pull/13 .

1.0a5 (2012-04-21)
------------------

- Slightly less sucky way to ignore objects during scanning that are only
  imported into a module but not actually defined there.  See 1.0a4 change
  notes for rationale.  Now instead of checking whether the module of the
  *scanned object* matches the module being scanned, we check whether the
  module of the *Venusian attachment* matches the module being scanned.  This
  allows some genuine uses of imported objects as Venusian scan targets while
  preventing inappropriate double-scanning of objects that have a venusian
  attachment which just happen to be imported into other scanned modules.

- Add ``dev`` and ``docs`` setup.py commands (ala Pyramid).

1.0a4 (2012-04-16)
------------------

- Attempt to ignore objects during scanning that are only imported into a
  module but not actually defined there.  This is a semantics change, but
  it's the right thing to do, because I found myself facing a situation like
  this::

    # in a module named "one"

    from two import anotheradecoratedthing
    @adecorator
    def adecoratedthing(): pass

    # and scanning both modules
    scan('one')
    scan('two')

  In this case you'd wind up with two repeated registrations for
  "anotherdecoratedthing", which isn't what anyone expects.

1.0a3 (2012-02-08)
------------------

- Add an ``ignore`` argument to the ``scan`` method of a ``Scanner``.  This
  argument allows a user to ignore packages, modules, and global objects by
  name during a ``scan``.  See the "ignore Scan Argument" in the narrative
  documentation for more details.

1.0a2 (2011-09-02)
------------------

- Close ImpLoader file handle to avoid resource warnings on Python 3.

1.0a1 (2011-08-27)
------------------

- Python 3 compatibility.

- Allow an ``onerror`` callback to be passed to ``Scanner.scan()``.

0.9 (2011-06-18)
----------------

- Prevent corner case scan-time exception when trying to introspect insane
  module-scope objects.  See https://github.com/Pylons/venusian/issues/5 .

0.8 (2011-04-30)
----------------

- Normal "setup.py test" can't support running the venusian tests under py
  2.4 or 2.5; when it scans the 'classdecorators' fixture, it barfs.  To get
  around this, we used to depend on ``nose`` in ``setup_requires`` and tell
  "setup.py test" to use nose by setting test_suite to "nose.collector" but
  we can't anymore because folks use Venusian in systems which install from
  pip bundles; pip bundles do not support setup_requires.  So, sorry, we're
  painted into a corner; at this point you just have to know to install nose
  and run "setup.py nosetests" rather than "setup.py test".  Or just run
  "tox" which tests it under all Pythons.

0.7 (2011-03-16)
----------------

- Use Pylons theme in documentation.

- Fix orphaned pyc test on pypy.

- Fix GitHub Issue #1: subclasses of decorated classes that do not
  have any decorations should not inherit the decorations of their
  parent classes. 

- Fix GitHub Issue #2: scans should only "find" each object once per
  scan, regardless of how many modules that object is imported into.

0.6 (2011-01-09)
----------------

- Some metaclasses (Elixir's) don't raise an AttributeError when asked for a
  nonexistent attribute during a scan.  We now catch all exceptions when
  interrogating an object for ``__venusian_callbacks__`` rather than just
  AttributeError.

0.5 (2010-12-19)
----------------

- Make ``codeinfo`` attribute available as an attribute of the AttachInfo
  object. It will be a tuple in the form ``(filename, lineno, function,
  sourceline)`` representing the context of the venusian decorator.  Eg.
  ``('/home/chrism/projects/venusian/tests/test_advice.py', 81,
  'testCallInfo', 'add_handler(foo, bar)')``

0.4 (2010-09-03)
----------------

- Bug fix: when a venusian decorator used as a class decorator was
  used against both a class *and* a subclass of that class, the
  superclass and subclass would effectively share the same set of
  callbacks.  This was not the intent: each class declaration should
  have its own local set of callbacks; callbacks added via decorations
  should not be inherited, and a superclass should not receive its
  subclass' decorations.

- Arrange test fixtures into a single directory.

0.3 (2010-06-24)
----------------

- Ignore orphaned modules (``.pyc`` or ``.pyo`` files without a
  corresponding ``.py`` file) during a scan.

0.2 (2010-04-18)
----------------

- Add the concept of scan categories (see the "Scan Categories"
  section of the documentation) to allow an application to make use of
  more than one Venusian-using framework simultaneously.

0.1 (2010-02-15)
----------------

- Initial release.
