.. _faq:

==================================
 FAQ: Frequently Asked Questions
==================================

.. include:: includes/faq.txt
