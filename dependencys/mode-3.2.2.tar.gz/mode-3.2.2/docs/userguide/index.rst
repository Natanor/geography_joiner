.. _guide:

===============
 User Guide
===============

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 1

    services
