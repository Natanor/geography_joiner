=====================================================
 ``mode.locals``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.locals

.. automodule:: mode.locals
    :members:
    :undoc-members:
