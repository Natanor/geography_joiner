=====================================================
 ``mode.loop.eventlet``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.loop.eventlet

.. warning::

    Importing this module directly will set the global event loop.
    See :mod:`faust.loop` for more information.

