=====================================================
 ``mode.utils.aiter``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.utils.aiter

.. automodule:: mode.utils.aiter
    :members:
    :undoc-members:
