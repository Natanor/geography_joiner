=====================================================
 ``mode.utils.times``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.utils.times

.. automodule:: mode.utils.times
    :members:
    :undoc-members:
