=====================================================
 ``mode.exceptions``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.exceptions

.. automodule:: mode.exceptions
    :members:
    :undoc-members:
