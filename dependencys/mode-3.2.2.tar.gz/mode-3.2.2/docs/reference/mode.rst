=====================================================
 ``mode``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode

.. automodule:: mode
    :members:
    :undoc-members:
