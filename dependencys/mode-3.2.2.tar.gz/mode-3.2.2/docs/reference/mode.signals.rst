=====================================================
 ``mode.signals``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.signals

.. automodule:: mode.signals
    :members:
    :undoc-members:
