=====================================================
 ``mode.debug``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.debug

.. automodule:: mode.debug
    :members:
    :undoc-members:
