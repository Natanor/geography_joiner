=====================================================
 ``mode.utils.text``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.utils.text

.. automodule:: mode.utils.text
    :members:
    :undoc-members:
