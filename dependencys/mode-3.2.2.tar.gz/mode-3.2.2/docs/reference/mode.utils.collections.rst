=====================================================
 ``mode.utils.collections``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.utils.collections

.. automodule:: mode.utils.collections
    :members:
    :undoc-members:
