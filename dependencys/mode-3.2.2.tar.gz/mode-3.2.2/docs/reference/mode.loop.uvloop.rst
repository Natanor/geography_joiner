=====================================================
 ``mode.loop.uvloop``
=====================================================

.. contents::
    :local:
.. currentmodule:: mode.loop.uvloop

.. warning::

    Importing this module directly will set the global event loop.
    See :mod:`faust.loop` for more information.

