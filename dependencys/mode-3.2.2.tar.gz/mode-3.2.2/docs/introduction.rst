.. _intro:

=============================
 Introduction to Mode
=============================

.. contents::
    :local:
    :depth: 1

.. include:: includes/introduction.txt

What do I need?
===============

.. sidebar:: Version Requirements
    :subtitle: Mode version 1.0 runs on

    - Python 3.6.2


Mode requires Python 3.6.2 or later.

There's currently no plan to port Mode to earlier Python versions,
please get in touch if this is something that you want to work on.
