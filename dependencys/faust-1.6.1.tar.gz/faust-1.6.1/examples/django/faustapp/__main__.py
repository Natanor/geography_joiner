from faustapp.app import app
app.main()  # start entry point for :program:`faust`
