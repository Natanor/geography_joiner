=====================================================
 ``faust.worker``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.worker

.. automodule:: faust.worker
    :members:
    :undoc-members:
