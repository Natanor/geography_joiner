=====================================================
 ``faust.cli.clean_versions``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.clean_versions

.. automodule:: faust.cli.clean_versions
    :members:
    :undoc-members:
