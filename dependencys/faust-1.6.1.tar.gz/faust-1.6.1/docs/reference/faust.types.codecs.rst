=====================================================
 ``faust.types.codecs``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.codecs

.. automodule:: faust.types.codecs
    :members:
    :undoc-members:
