=====================================================
 ``faust.agents.agent``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.agents.agent

.. automodule:: faust.agents.agent
    :members:
    :undoc-members:
