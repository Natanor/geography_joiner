=====================================================
 ``faust.transport.drivers.aiokafka``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.transport.drivers.aiokafka

.. automodule:: faust.transport.drivers.aiokafka
    :members:
    :undoc-members:
