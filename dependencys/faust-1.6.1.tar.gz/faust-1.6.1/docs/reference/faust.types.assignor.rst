=====================================================
 ``faust.types.assignor``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.assignor

.. automodule:: faust.types.assignor
    :members:
    :undoc-members:
