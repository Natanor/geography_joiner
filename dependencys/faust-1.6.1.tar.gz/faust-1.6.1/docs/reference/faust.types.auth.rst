=====================================================
 ``faust.types.auth``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.auth

.. automodule:: faust.types.auth
    :members:
    :undoc-members:
