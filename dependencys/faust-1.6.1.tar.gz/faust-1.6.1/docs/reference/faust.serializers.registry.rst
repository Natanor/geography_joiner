=====================================================
 ``faust.serializers.registry``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.serializers.registry

.. automodule:: faust.serializers.registry
    :members:
    :undoc-members:
