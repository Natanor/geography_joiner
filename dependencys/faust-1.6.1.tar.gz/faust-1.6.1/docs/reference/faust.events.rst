=====================================================
 ``faust.events``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.events

.. automodule:: faust.events
    :members:
    :undoc-members:
