=====================================================
 ``faust.types.agents``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.agents

.. automodule:: faust.types.agents
    :members:
    :undoc-members:
