=====================================================
 ``faust.utils.terminal.tables``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.terminal.tables

.. automodule:: faust.utils.terminal.tables
    :members:
    :undoc-members:
