=====================================================
 ``faust.web.cache.exceptions``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.cache.exceptions

.. automodule:: faust.web.cache.exceptions
    :members:
    :undoc-members:
