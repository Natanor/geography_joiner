=====================================================
 ``faust.utils.json``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.json

.. automodule:: faust.utils.json
    :members:
    :undoc-members:
