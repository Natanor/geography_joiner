=====================================================
 ``faust.cli.model``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.model

.. automodule:: faust.cli.model
    :members:
    :undoc-members:
