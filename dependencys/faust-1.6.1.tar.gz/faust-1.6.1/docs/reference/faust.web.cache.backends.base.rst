=====================================================
 ``faust.web.cache.backends.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.cache.backends.base

.. automodule:: faust.web.cache.backends.base
    :members:
    :undoc-members:
