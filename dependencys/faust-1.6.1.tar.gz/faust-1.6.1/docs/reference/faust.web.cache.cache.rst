=====================================================
 ``faust.web.cache.cache``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.cache.cache

.. automodule:: faust.web.cache.cache
    :members:
    :undoc-members:
