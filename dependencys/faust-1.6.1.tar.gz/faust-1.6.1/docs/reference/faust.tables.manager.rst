=====================================================
 ``faust.tables.manager``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.manager

.. automodule:: faust.tables.manager
    :members:
    :undoc-members:
