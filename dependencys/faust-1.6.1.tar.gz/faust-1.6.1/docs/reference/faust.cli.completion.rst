=====================================================
 ``faust.cli.completion``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.completion

.. automodule:: faust.cli.completion
    :members:
    :undoc-members:
