=====================================================
 ``faust.assignor.partition_assignor``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.assignor.partition_assignor

.. automodule:: faust.assignor.partition_assignor
    :members:
    :undoc-members:
