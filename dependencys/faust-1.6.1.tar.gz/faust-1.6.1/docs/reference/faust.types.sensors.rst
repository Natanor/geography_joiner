=====================================================
 ``faust.types.sensors``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.sensors

.. automodule:: faust.types.sensors
    :members:
    :undoc-members:
