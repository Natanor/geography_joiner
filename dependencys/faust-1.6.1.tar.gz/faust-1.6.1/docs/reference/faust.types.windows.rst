=====================================================
 ``faust.types.windows``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.windows

.. automodule:: faust.types.windows
    :members:
    :undoc-members:
