=====================================================
 ``faust.utils.iso8601``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.iso8601

.. automodule:: faust.utils.iso8601
    :members:
    :undoc-members:
