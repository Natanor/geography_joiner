=====================================================
 ``faust.fixups.django``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.fixups.django

.. automodule:: faust.fixups.django
    :members:
    :undoc-members:
