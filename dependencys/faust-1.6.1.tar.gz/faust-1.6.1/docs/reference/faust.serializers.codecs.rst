=====================================================
 ``faust.serializers.codecs``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.serializers.codecs

.. automodule:: faust.serializers.codecs
    :members:
    :undoc-members:
