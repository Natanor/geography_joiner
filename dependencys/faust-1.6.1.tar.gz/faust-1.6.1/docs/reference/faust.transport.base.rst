=====================================================
 ``faust.transport.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.transport.base

.. automodule:: faust.transport.base
    :members:
    :undoc-members:
