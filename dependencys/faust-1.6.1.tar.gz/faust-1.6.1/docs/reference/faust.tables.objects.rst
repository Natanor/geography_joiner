=====================================================
 ``faust.tables.objects``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.objects

.. automodule:: faust.tables.objects
    :members:
    :undoc-members:
