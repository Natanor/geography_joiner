=====================================================
 ``faust.utils.urls``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.urls

.. automodule:: faust.utils.urls
    :members:
    :undoc-members:
