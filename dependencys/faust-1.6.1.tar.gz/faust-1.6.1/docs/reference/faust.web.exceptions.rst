=====================================================
 ``faust.web.exceptions``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.exceptions

.. automodule:: faust.web.exceptions
    :members:
    :undoc-members:
