=====================================================
 ``faust.agents.manager``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.agents.manager

.. automodule:: faust.agents.manager
    :members:
    :undoc-members:
