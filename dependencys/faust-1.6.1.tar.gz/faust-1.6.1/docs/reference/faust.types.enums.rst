=====================================================
 ``faust.types.enums``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.enums

.. automodule:: faust.types.enums
    :members:
    :undoc-members:
