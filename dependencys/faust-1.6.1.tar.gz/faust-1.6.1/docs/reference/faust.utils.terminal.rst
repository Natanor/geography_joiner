=====================================================
 ``faust.utils.terminal``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.terminal

.. automodule:: faust.utils.terminal
    :members:
    :undoc-members:
