=====================================================
 ``faust.web.cache.backends``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.cache.backends

.. automodule:: faust.web.cache.backends
    :members:
    :undoc-members:
