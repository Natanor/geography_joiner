=====================================================
 ``faust.app.router``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.app.router

.. automodule:: faust.app.router
    :members:
    :undoc-members:
