=====================================================
 ``faust.models.record``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.models.record

.. automodule:: faust.models.record
    :members:
    :undoc-members:
