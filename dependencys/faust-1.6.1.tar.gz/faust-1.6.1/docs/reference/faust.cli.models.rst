=====================================================
 ``faust.cli.models``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.models

.. automodule:: faust.cli.models
    :members:
    :undoc-members:
