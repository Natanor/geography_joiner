=====================================================
 ``faust.utils.terminal.spinners``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.utils.terminal.spinners

.. automodule:: faust.utils.terminal.spinners
    :members:
    :undoc-members:
