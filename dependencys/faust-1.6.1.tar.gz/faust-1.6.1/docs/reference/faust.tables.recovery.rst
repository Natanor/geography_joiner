=====================================================
 ``faust.tables.recovery``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.recovery

.. automodule:: faust.tables.recovery
    :members:
    :undoc-members:
