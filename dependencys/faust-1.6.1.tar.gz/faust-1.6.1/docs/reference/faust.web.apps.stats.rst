=====================================================
 ``faust.web.apps.stats``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.apps.stats

.. automodule:: faust.web.apps.stats
    :members:
    :undoc-members:
