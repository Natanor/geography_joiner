=====================================================
 ``faust.agents.actor``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.agents.actor

.. automodule:: faust.agents.actor
    :members:
    :undoc-members:
