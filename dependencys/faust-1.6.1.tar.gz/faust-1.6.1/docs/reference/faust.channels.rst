=====================================================
 ``faust.channels``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.channels

.. automodule:: faust.channels
    :members:
    :undoc-members:
