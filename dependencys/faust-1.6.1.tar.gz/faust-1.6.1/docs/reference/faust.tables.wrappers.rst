=====================================================
 ``faust.tables.wrappers``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables.wrappers

.. automodule:: faust.tables.wrappers
    :members:
    :undoc-members:
