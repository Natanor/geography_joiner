=====================================================
 ``faust.cli.send``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.send

.. automodule:: faust.cli.send
    :members:
    :undoc-members:
