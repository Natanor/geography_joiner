=====================================================
 ``faust.tables``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.tables

.. automodule:: faust.tables
    :members:
    :undoc-members:
