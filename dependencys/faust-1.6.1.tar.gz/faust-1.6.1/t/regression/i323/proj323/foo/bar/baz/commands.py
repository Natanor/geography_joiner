from proj323 import app


@app.command()
async def my_process_command_i323():
    print('HELLO WORLD #323')
