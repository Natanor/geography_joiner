from proj324 import app


@app.command()
async def my_process_command_i324():
    print('HELLO WORLD #324')
