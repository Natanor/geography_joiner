from proj324.faust import app

print('IMPORTS __MAIN__')

app.main()
