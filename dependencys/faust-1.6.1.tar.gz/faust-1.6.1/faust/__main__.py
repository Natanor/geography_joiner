"""Command-line entry point."""
# pragma: no cover
from faust.cli.faust import cli

cli()
