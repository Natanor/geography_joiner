.. include:: ../README.rst

.. toctree::
   :hidden:

   api
   changelog
